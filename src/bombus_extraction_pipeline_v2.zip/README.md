# Pipeline d'extraction et de normalisation

Architecture proposée :

```text
src/
├── obb_detector/
│   ├── train.py
│   ├── evaluate.py
│   ├── predict.py
│   ├── prepare_dataset.py
│   └── validate_*.py
│
└── extraction/
    ├── extraction_io.py
    ├── extract_yoloe.py
    ├── extract_obb.py
    ├── normalize_crop.py
    ├── detection.py       # module YOLOE existant
    └── qa_clip.py          # module CLIP existant
```

`obb_detector` construit et évalue le modèle. `extraction` applique le modèle à des images réelles.

## Étape 1 : extraction

Les deux extracteurs lisent uniquement `images.csv` pour obtenir `image_id`, `specimen_id`, `dataset` et `raw_path`.

Ils produisent le même CSV intermédiaire contenant l'OBB de l'aile. Aucun crop normalisé n'est produit à cette étape.

### YOLO-OBB

```powershell
python .\src\extraction\extract_obb.py `
    --images-csv .\data\manifest\images.csv `
    --output-csv .\data\extraction\obb.csv `
    --model .\runs\obb\weights\best.pt `
    --imgsz 1024 `
    --conf 0.10
```

### YOLOE + SAM / segmentation

```powershell
python .\src\extraction\extract_yoloe.py `
    --images-csv .\data\manifest\images.csv `
    --output-csv .\data\extraction\yoloe.csv `
    --ref .\data\references\ref.json `
    --ref-crops .\data\references\crops `
    --model yoloe-11s-seg.pt `
    --imgsz 1024 `
    --conf 0.05
```

La logique YOLOE + sélection CLIP est conservée côté extraction. La normalisation n'est plus appelée depuis l'extracteur.

## Étape 2 : normalisation

La même commande fonctionne avec le CSV YOLOE ou le CSV YOLO-OBB.

```powershell
python .\src\extraction\normalize_crop.py `
    --images-csv .\data\manifest\images.csv `
    --detections-csv .\data\extraction\obb.csv `
    --output-root .\data\crops\obb `
    --csv .\data\extraction\obb_normalized.csv
```

La normalisation :

1. redresse l'aile selon le grand axe de l'OBB ;
2. ajoute le contexte autour de l'OBB ;
3. agrandit le crop dans la dimension courte jusqu'au ratio 2:1 en prenant les pixels réels de l'image ;
4. utilise une réflexion uniquement si la zone demandée dépasse réellement le bord de l'image ;
5. redimensionne directement en 512x256 ;
6. écrit un JPEG grayscale.

Il n'y a donc plus de bandes blanches ajoutées pour obtenir le ratio 2:1.

## Important pour la comparaison

Pour comparer YOLOE et YOLO-OBB, utilisez exactement le même `images.csv`, les mêmes paramètres de normalisation et deux CSV d'extraction différents.

```text
images.csv
   ├── extract_yoloe.py  -> yoloe.csv  -> normalize_crop.py -> crops/yoloe
   └── extract_obb.py    -> obb.csv    -> normalize_crop.py -> crops/obb
```

Les métriques de temps sont séparées entre extraction et normalisation, ce qui permet d'estimer le gain réel du détecteur léger.

## Comparaison du temps

`extract_yoloe.py` et `extract_obb.py` mesurent le temps de détection par image. `normalize_crop.py` mesure séparément le temps de normalisation. Le coût total peut donc être comparé sans mélanger les deux étapes.

## Pas de bande blanche

La normalisation ne fait plus de letterbox avec un canvas blanc. Après redressement, le crop est élargi dans sa dimension courte avec les pixels disponibles autour de l'OBB afin d'atteindre 2:1. Le crop est ensuite redimensionné directement en 512x256. Une réflexion de bord n'est utilisée qu'en dernier recours lorsque la zone 2:1 dépasse réellement les limites de l'image.
