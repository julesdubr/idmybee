"""Extraction des ailes avec YOLOE + SAM/segmentation.

Ce script ne normalise pas les crops. Il produit uniquement les OBB candidates
retenues par YOLOE, afin que la même normalisation soit ensuite appliquée à
YOLOE et YOLO-OBB.

Il conserve la logique de sélection de ton pipeline existant :
YOLOE segmentation -> top-k candidats -> score CLIP -> OBB du meilleur candidat.
"""

from __future__ import annotations

import argparse
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import cv2

from extraction_io import COMMON_FIELDS, read_images_csv, resolve_raw_path, select_images, write_rows
from normalize_crop import normalize_crop, read_image

import detection
import qa_clip


def parse_args():
    parser = argparse.ArgumentParser(description="Détection des ailes par YOLOE + SAM.")
    parser.add_argument("--images-csv", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--ref", required=True, help="JSON des références YOLOE.")
    parser.add_argument("--ref-crops", required=True, help="Dossier des crops de référence CLIP.")
    parser.add_argument("--model", default="yoloe-11s-seg.pt")
    parser.add_argument("--dataset", default=None)
    parser.add_argument("--image-id", action="append", default=None)
    parser.add_argument("--base-dir", default=None)
    parser.add_argument("--conf", type=float, default=0.05)
    parser.add_argument("--imgsz", type=int, default=1024)
    parser.add_argument("--device", default=None)
    parser.add_argument("--topk-candidates", type=int, default=1)
    parser.add_argument("--min-aspect-ok", type=float, default=1.3)
    parser.add_argument("--min-similarity", type=float, default=0.0)
    parser.add_argument("--keep-duplicates", action="store_true")
    return parser.parse_args()


def mask_to_obb(mask_points: np.ndarray, image_width: int, image_height: int):
    if mask_points is None or len(mask_points) < 3:
        return None

    import cv2

    rect = cv2.minAreaRect(mask_points.astype(np.float32))
    (center_x, center_y), (width, height), _ = rect
    if width < 1 or height < 1:
        return None

    box = cv2.boxPoints(rect).astype(np.float32)

    # Même convention que crops.csv : quatre coins x,y, normalisés.
    box[:, 0] /= image_width
    box[:, 1] /= image_height

    aspect = max(width, height) / max(min(width, height), 1e-6)
    return box, aspect


def process_one(model, target, ref_embs, clip_model, clip_preprocess, clip_device, args):
    start = time.perf_counter()

    row = {
        "image_id": target.get("image_id", ""),
        "specimen_id": target.get("specimen_id", ""),
        "dataset": target.get("dataset", ""),
        "status": "FAILED",
        "error_reason": "",
        "confidence": "",
        "selection_score": "",
        "n_detections": "0",
        "x1": "", "y1": "", "x2": "", "y2": "",
        "x3": "", "y3": "", "x4": "", "y4": "",
        "processing_time_s": "",
        "processed_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }

    image = read_image(Path(target["path"]))
    if image is None:
        row["error_reason"] = "image_illisible_ou_format_non_supporte"
        row["processing_time_s"] = f"{time.perf_counter() - start:.4f}"
        return row

    try:
        results = model.predict(
            image,
            conf=args.conf,
            imgsz=args.imgsz,
            device=args.device,
            verbose=False,
        )
        result = results[0]
        count = len(result.boxes) if result.boxes is not None else 0
        row["n_detections"] = str(count)

        if count == 0:
            row["error_reason"] = "aucune_detection"
            row["processing_time_s"] = f"{time.perf_counter() - start:.4f}"
            return row

        if result.masks is None:
            row["error_reason"] = "pas_de_masque"
            row["processing_time_s"] = f"{time.perf_counter() - start:.4f}"
            return row

        confidences = result.boxes.conf.cpu().numpy()
        order = np.argsort(-confidences)
        topk = order[:max(1, args.topk_candidates)]

        candidates = []
        for i in topk:
            candidate = mask_to_obb(
                result.masks.xy[i],
                image.shape[1],
                image.shape[0],
            )
            if candidate is None:
                continue

            box, aspect = candidate

            points_pixels = cv2.boxPoints(cv2.minAreaRect(result.masks.xy[i].astype(np.float32)))
            preview, _ = normalize_crop(
                image,
                points_pixels,
                pad=0.10,
                out_width=512,
                out_height=256,
            )
            if preview is None:
                continue

            similarity = qa_clip.clip_similarity(
                preview,
                ref_embs,
                clip_model,
                clip_preprocess,
                clip_device,
            )

            candidates.append(
                {
                    "confidence": float(confidences[i]),
                    "similarity": float(similarity),
                    "aspect": float(aspect),
                    "box": box,
                }
            )

        if not candidates:
            row["error_reason"] = "obb_degenere"
            row["processing_time_s"] = f"{time.perf_counter() - start:.4f}"
            return row

        best = max(candidates, key=lambda item: item["similarity"])

        if best["similarity"] < args.min_similarity:
            row["error_reason"] = "similarite_insuffisante"
        elif best["aspect"] < args.min_aspect_ok:
            row["error_reason"] = "aspect_ratio_insuffisant"
        else:
            row["status"] = "OK"

        row["confidence"] = f"{best['confidence']:.4f}"
        row["selection_score"] = f"{best['similarity']:.4f}"
        values = best["box"].reshape(-1)
        for i in range(4):
            row[f"x{i + 1}"] = f"{values[2 * i]:.8f}"
            row[f"y{i + 1}"] = f"{values[2 * i + 1]:.8f}"

    except Exception as exc:
        row["error_reason"] = f"exception: {exc}"

    row["processing_time_s"] = f"{time.perf_counter() - start:.4f}"
    return row


def main():
    args = parse_args()
    images = read_images_csv(Path(args.images_csv))
    targets = select_images(
        images,
        dataset=args.dataset,
        image_ids=set(args.image_id) if args.image_id else None,
        skip_duplicates=not args.keep_duplicates,
    )

    print(f"Images à traiter : {len(targets)}")

    from ultralytics import YOLOE
    from ultralytics.models.yolo.yoloe import YOLOEVPSegPredictor

    references = detection.load_references(args.ref)
    model = YOLOE(args.model)
    detection.bake_references(
        model,
        references,
        YOLOEVPSegPredictor,
        imgsz=args.imgsz,
        device=args.device,
    )

    clip_device = args.device or ("cuda" if qa_clip.cuda_available() else "cpu")
    clip_model, clip_preprocess = qa_clip.load_clip(clip_device)
    ref_crop_paths = list(Path(args.ref_crops).iterdir())
    ref_embs = qa_clip.load_ref_embeddings(
        ref_crop_paths,
        clip_model,
        clip_preprocess,
        clip_device,
    )

    rows = []
    base_dir = Path(args.base_dir) if args.base_dir else None

    for index, source in enumerate(targets, start=1):
        target = dict(source)
        target["path"] = resolve_raw_path(source["raw_path"], base_dir)
        row = process_one(
            model,
            target,
            ref_embs,
            clip_model,
            clip_preprocess,
            clip_device,
            args,
        )
        rows.append(row)

        if index % 50 == 0 or index == len(targets):
            print(f"[{index}/{len(targets)}]")

    write_rows(Path(args.output_csv), rows, COMMON_FIELDS)
    print(f"CSV : {args.output_csv}")


if __name__ == "__main__":
    main()
