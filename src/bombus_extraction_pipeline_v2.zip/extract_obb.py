"""Extraction des OBB avec le détecteur YOLO-OBB spécialisé."""

from __future__ import annotations

import argparse
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from ultralytics import YOLO

from extraction_io import COMMON_FIELDS, read_images_csv, resolve_raw_path, select_images, write_rows
from normalize_crop import read_image


def parse_args():
    parser = argparse.ArgumentParser(description="Détection des ailes par YOLO-OBB.")
    parser.add_argument("--images-csv", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--dataset", default=None)
    parser.add_argument("--image-id", action="append", default=None)
    parser.add_argument("--base-dir", default=None)
    parser.add_argument("--imgsz", type=int, default=1024)
    parser.add_argument("--conf", type=float, default=0.10)
    parser.add_argument("--device", default=None)
    parser.add_argument("--max-det", type=int, default=10)
    parser.add_argument("--keep-duplicates", action="store_true")
    return parser.parse_args()


def predict_one(model, image, args):
    results = model.predict(
        image,
        imgsz=args.imgsz,
        conf=args.conf,
        device=args.device,
        max_det=args.max_det,
        verbose=False,
    )

    result = results[0]
    if result.obb is None or len(result.obb) == 0:
        return None, 0

    count = len(result.obb)
    confs = result.obb.conf.detach().cpu().numpy()
    best = int(np.argmax(confs))

    points = result.obb.xyxyxyxy[best].detach().cpu().numpy().reshape(4, 2)
    h, w = image.shape[:2]
    points[:, 0] /= w
    points[:, 1] /= h

    return {
        "confidence": float(confs[best]),
        "points": points,
    }, count


def main():
    args = parse_args()
    images = read_images_csv(Path(args.images_csv))
    targets = select_images(
        images,
        dataset=args.dataset,
        image_ids=set(args.image_id) if args.image_id else None,
        skip_duplicates=not args.keep_duplicates,
    )

    print(f"Images à traiter : {len(targets)}")
    model = YOLO(args.model)

    rows = []
    base_dir = Path(args.base_dir) if args.base_dir else None

    for index, source in enumerate(targets, start=1):
        start = time.perf_counter()
        raw_path = resolve_raw_path(source["raw_path"], base_dir)

        row = {
            "image_id": source.get("image_id", ""),
            "specimen_id": source.get("specimen_id", ""),
            "dataset": source.get("dataset", ""),
            "status": "FAILED",
            "error_reason": "",
            "confidence": "",
            "selection_score": "",
            "n_detections": "0",
            "x1": "", "y1": "", "x2": "", "y2": "",
            "x3": "", "y3": "", "x4": "", "y4": "",
            "processing_time_s": "",
            "processed_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }

        image = read_image(raw_path)
        if image is None:
            row["error_reason"] = "image_illisible_ou_format_non_supporte"
        else:
            try:
                detection, count = predict_one(model, image, args)
                row["n_detections"] = str(count)

                if detection is None:
                    row["error_reason"] = "aucune_detection"
                else:
                    row["status"] = "OK"
                    row["confidence"] = f"{detection['confidence']:.4f}"
                    points = detection["points"]
                    for i, (x, y) in enumerate(points, start=1):
                        row[f"x{i}"] = f"{x:.8f}"
                        row[f"y{i}"] = f"{y:.8f}"
            except Exception as exc:
                row["error_reason"] = f"exception: {exc}"

        row["processing_time_s"] = f"{time.perf_counter() - start:.4f}"
        rows.append(row)

        if index % 100 == 0 or index == len(targets):
            print(f"[{index}/{len(targets)}]")

    write_rows(Path(args.output_csv), rows, COMMON_FIELDS)
    print(f"CSV : {args.output_csv}")


if __name__ == "__main__":
    main()
